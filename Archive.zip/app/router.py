from fastapi import APIRouter, Header, Depends, HTTPException, status
from datetime import timedelta
from app.spiders.spider_pro import PubSpider
from app.sql_app import schemas
from app.sql_app.schemas import WaterSpiderBase
from app.utils import auth
from app.utils.login import authenticate_user


# Create a router fileter to verify the token
'''def get_authenticated(access_token: str = Header(None)):
    if not auth.verify_token(access_token) or access_token is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return {"token": access_token}'''


def get_authenticated(authorization: str = Header(None)):
    """
    Dependency to extract the token from the Authorization header.
    It expects the header to have the format "Bearer <token>".
    """
    if authorization is None:
        raise HTTPException(status_code=401, detail="Authorization header missing")

    try:
        scheme, token = authorization.split()
        if scheme.lower() != "bearer":
            raise HTTPException(status_code=401, detail="Authorization scheme not Bearer")
        if not auth.verify_token(token) or token is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token",
                headers={"Authenticate": "Bearer"},
            )
        return {"token": token}
    except ValueError:
        raise HTTPException(status_code=401, detail="Invalid Authorization header format")


router = APIRouter(dependencies=[Depends(get_authenticated)])
router_login = APIRouter()


@router_login.post("/login")
async def login_for_access_token(form_data: schemas.UserInDb):
    user = await authenticate_user(form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token_expires = timedelta(minutes=auth.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = auth.create_access_token(
        data={"sub": user.username}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}


def say_hello():
    print("Hello World")


@router.get("/")
async def root():
    return {"message": "Hello World"}


@router.get("/hello/{name}")
async def say_hello(name: str):
    return {"message": f"Hello {name}"}


@router.get("/test")
async def pub_grab_all() -> bool:
    new_pub_spider = PubSpider()
    await new_pub_spider.spider_grab()
    await new_pub_spider.spider_insert()
    return True


@router.get("/inspect")
async def inspect(offset: int = 0, limit: int | None = None) -> list[WaterSpiderBase]:
    new_pub_spider = PubSpider()
    # Need to process the special characters in the response such as ' and "
    return await new_pub_spider.spider_read(offset=offset, limit=limit)


@router.get("/update")
async def update() -> bool:
    new_pub_spider = PubSpider()
    return await new_pub_spider.spider_update()


@router.post("/test")
async def test(token: str = Header(None)):
    if not auth.verify_token(token):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return {"message": "Hello World"}
