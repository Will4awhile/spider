# Create a hashed password for the user
from app.utils import auth


def create_user(username: str, password: str):
    hashed_password = auth.get_password_hashed(password)
    return {"username": username, "hashed_password": hashed_password}

print(create_user("test", "test"))