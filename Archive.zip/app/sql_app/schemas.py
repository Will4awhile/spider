from pydantic import BaseModel, ConfigDict


class WaterSpiderBase(BaseModel):
    id: int | None = None
    title: str
    source: str
    link: str
    category: str
    deleted: int | None = None
    read: int | None = None
    release_date: str | None = None
    fav: int | None = None

    model_config = ConfigDict(from_attributes=True)


class UserBase(BaseModel):
    id: int | None = None
    username: str

    model_config = ConfigDict(from_attributes=True)


class UserInDb(UserBase):
    password: str | None = None

    model_config = ConfigDict(from_attributes=True)