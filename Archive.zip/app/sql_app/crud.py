from sqlalchemy import select
from sqlalchemy.exc import SQLAlchemyError
from .database import AsyncSessionLocal
from .models import WaterSpider
import logging

from .schemas import WaterSpiderBase


async def insert_spiders(spider_data: list) -> bool:
    """
    Asynchronously inserts multiple WaterSpider records into the database.

    :param spider_data: A list of dictionaries where each dictionary represents a WaterSpider record.
    :return: True if the operation was successful, False otherwise.
    """
    async with AsyncSessionLocal() as session:
        try:
            async with session.begin():
                for spider in spider_data:
                    session.add(WaterSpider(**spider.dict()))
            await session.commit()
            logging.info(f"Successfully inserted {len(spider_data)} spiders into the database.")
        except SQLAlchemyError as e:
            logging.error(f"Failed to insert spiders into the database: {e}")
            return False
    return True


async def insert_spider(spider_data: dict) -> bool:
    """
    Asynchronously inserts a single WaterSpider record into the database.

    :param spider_data: A dictionary representing a WaterSpider record.
    :return: True if the operation was successful, False otherwise.
    """
    async with AsyncSessionLocal() as session:
        try:
            async with session.begin():
                session.add(WaterSpider(**spider_data))
            await session.commit()
            logging.info(f"Successfully inserted a spider into the database.")
        except SQLAlchemyError as e:
            logging.error(f"Failed to insert a spider into the database: {e}")
            return False
    return True


async def get_spiders() -> list:
    """
    Asynchronously retrieves all WaterSpider records from the database.

    :return: A list of WaterSpider records.
    """
    async with AsyncSessionLocal() as session:
        try:
            async with session.begin():
                # Correct way to prepare and execute a query asynchronously where category is Utility
                query = select(WaterSpider)

                result = await session.execute(query)
                spiders = result.scalars().all()  # Fetch all results
                return [WaterSpiderBase.from_orm(spider) for spider in spiders]
        except SQLAlchemyError as e:
            logging.error(f"Failed to retrieve spiders from the database: {e}")
            return []


async def get_spider_by_source(source: str, offset: int = 0, limit: int = None) -> list:
    async with AsyncSessionLocal() as session:
        try:
            async with session.begin():
                query = select(WaterSpider).where(WaterSpider.source == source).offset(offset).limit(limit)
                result = await session.execute(query)
                spiders = result.scalars().all()  # Fetch all results
                return [WaterSpiderBase.from_orm(spider) for spider in spiders]
        except SQLAlchemyError as e:
            logging.error(f"Failed to retrieve spiders from the database: {e}")
            return []
