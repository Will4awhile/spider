from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# Database URL for MySQL
SQLALCHEMY_DATABASE_URL = "mysql+aiomysql://evie:!@##@!Welcome.IWA.2024@localhost:3306/spider?charset=utf8mb4"

# 创建异步的SQLAlchemy engine
engine = create_async_engine(SQLALCHEMY_DATABASE_URL,
                             echo=True,
                             echo_pool='debug',
                             )

# 创建基类
Base = declarative_base()

# Create the database tables
# Base.metadata.create_all(bind=engine)

# 创建异步SessionLocal
AsyncSessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine,
    class_=AsyncSession  # type: ignore
)
