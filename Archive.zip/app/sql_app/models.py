from datetime import datetime

from sqlalchemy import Column, Integer, String, DateTime
from .database import Base


class WaterSpider(Base):
    __tablename__: str = "water_spider"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, index=True)
    source = Column(String, index=True)
    link = Column(String, index=True)
    category = Column(String, index=True)
    deleted = Column(Integer, default=0, index=True)
    read = Column(Integer, default=0, index=True)
    release_date = Column(String, index=True)
    created_at = Column(DateTime, default=datetime.now)
    fav = Column(Integer, default=0, index=True)

    # Convert the object to a dictionary
    def to_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}


class UserPref(Base):
    __tablename__: str = "user_pref"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, index=True)
    entry_id = Column(Integer, index=True)
    deleted = Column(Integer, default=0, index=True)
    liked = Column(Integer, default=0, index=True)
    favorite = Column(Integer, default=0, index=True)

    # Convert the object to a dictionary
    def to_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}


class User(Base):
    __tablename__: str = "user"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, index=True)
    password = Column(String)

    # Convert the object to a dictionary
    def to_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}
