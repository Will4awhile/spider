from apscheduler.schedulers.asyncio import AsyncIOScheduler

scheduler = AsyncIOScheduler()


# @scheduler.scheduled_job("interval", seconds=1)
async def some_job():
    pass

job = scheduler.add_job(some_job, "interval", minutes=2, id="some_job")
