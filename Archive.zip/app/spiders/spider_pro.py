from playwright.async_api import async_playwright
from app.sql_app import schemas, crud
from app.spiders.SpiderBase import SpiderBase


class PubSpider(SpiderBase):

    async def spider_grab(self):
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            context = await browser.new_context(
                user_agent='Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) '
                           'Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0')

            page_1 = await context.new_page()
            link = 'https://www.pub.gov.sg'
            await page_1.goto('https://www.pub.gov.sg/Resources/News-Room/PressReleases')
            select_page_1 = '//*[@id="select-filter-by-category3"]'
            await page_1.locator(select_page_1).click()
            await page_1.select_option(select_page_1, index=0)
            rows = await page_1.query_selector_all('table > tbody > tr')
            for row in rows:
                if not await row.get_attribute('data-href'):
                    continue
                # for each tr tag, get the value of the first span
                first_span = await row.query_selector('td > span')
                date_text = await first_span.inner_text()

                # get the value of the span inside the td with class article-title
                article_title_span = await row.query_selector('.article-title > span')
                article_title_span_text = await article_title_span.inner_text()

                # get the value of a tag inside the td with name data-href
                data_href = await row.get_attribute('data-href')
                data_href_text = link + data_href.replace(' ', '-') if data_href else 'No link found'

                # print the values
                # print(f"Date: {date_text}, Title: {article_title_span_text}, Link: {data_href_text}")

                # write the values into the database
                self.content.append(schemas.WaterSpiderBase(title=article_title_span_text, source='PUB',
                                                            link=data_href_text, category='Utility',
                                                            release_date=date_text))
            await page_1.close()
            await browser.close()

    async def spider_insert(self):
        await crud.insert_spiders(self.content)
        return True

    async def spider_read(self, offset: int = 0, limit: int = None):
        source = 'PUB'
        self.existing_content = await crud.get_spider_by_source(source, offset, limit)
        return self.existing_content

    async def spider_compare(self):
        Different_in_L1 = [item for item in self.content
                           if not any(item.title == comp['title'] and
                                      item.release_date == comp['release_date'] for comp in self.existing_content)]
        if len(Different_in_L1) > 0:
            self.new_content = Different_in_L1
            return True
        else:
            return False

    async def spider_update(self):
        await self.spider_read()
        if len(self.existing_content) > 0:
            print('Existing content --- Yes')
        await self.spider_grab()
        if len(self.content) > 0:
            print('Content --- Yes')
        await self.spider_compare()
        if len(self.new_content) > 0:
            print('New content --- Yes')
            await crud.insert_spiders(self.new_content)
            return True
        else:
            return False
