from abc import abstractmethod, ABC


class SpiderBase(ABC):
    def __init__(self, category: str = '', source: str = '', source_link: str = '', release_date: str = '',
                 content: dict = None, existing_content: list = None, new_content: list = None):
        self.category = category
        self.source = source
        self.source_link = source_link
        self.release_date = release_date
        content = content or []
        self.content = [] or content
        # 'title': '', 'source': '', 'link': '', 'release_date': '', 'content': ''
        existing_content = existing_content or []
        self.existing_content = [] or existing_content
        new_content = new_content or []
        self.new_content = [] or new_content

    @abstractmethod
    def spider_grab(self):
        pass

    @abstractmethod
    def spider_insert(self):
        pass

    @abstractmethod
    def spider_read(self):
        pass

    @abstractmethod
    def spider_update(self):
        pass

    @abstractmethod
    def spider_compare(self):
        pass

