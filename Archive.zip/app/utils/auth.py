from datetime import datetime, timedelta, timezone
from jose import jwt, JWTError
import bcrypt
from ast import literal_eval

SECRET_KEY = "09d25e094faa6ca2556c818166b7a9563b93f7099f6f0f4caa6cf63b88e8d3e7"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 300


# Check if the provided password matches the stored password (hashed)
def verify_password(plain_password, str_password):
    password_byte_enc = plain_password.encode('utf-8')
    # Convert the hashed password to bytes
    hashed_password_bytes = literal_eval(str_password)
    return bcrypt.checkpw(password=password_byte_enc, hashed_password=hashed_password_bytes)


# Hash a password using bcrypt
def get_password_hashed(password):
    pwd_bytes = password.encode('utf-8')
    salt = bcrypt.gensalt()
    hashed_password = bcrypt.hashpw(password=pwd_bytes, salt=salt)
    return hashed_password


def create_access_token(data: dict, expires_delta: timedelta | None = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.now(timezone.utc) + expires_delta
    else:
        expire = datetime.now(timezone.utc) + timedelta(minutes=60)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt


# Verify the token and return the payload if successful is jwt error return None
def verify_token(token):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except JWTError:
        return None
