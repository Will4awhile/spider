from sqlalchemy.exc import SQLAlchemyError

from app.sql_app.database import AsyncSessionLocal
from sqlalchemy.future import select
from app.sql_app.models import User
from app.sql_app.schemas import UserInDb
from app.utils import auth
import logging


async def authenticate_user(username: str, password: str):
    user = await get_user(username)
    if not user or not auth.verify_password(password, user.password):
        return False
    return user


async def get_user(username: str):
    async with AsyncSessionLocal() as session:
        try:
            async with session.begin():
                query = select(User).where(User.username == username)
                result = await session.execute(query)
                user = result.scalars().first()
                return UserInDb.from_orm(user)
        except SQLAlchemyError as e:
            print(e)
            logging.error(f"Failed to retrieve spiders from the database: {e}")
            return None
