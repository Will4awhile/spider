from app.utils.auth import verify_token

m = ("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ0ZXN0MiIsImV4cCI6MTcxMTk0NjgxNH0.cYIFOAevfBRC0Yxa7ZLqT8-p7Aa3GEwQs6eg-vAB2Yc")

print(verify_token(m))

if verify_token(m):
    print("Valid token")