from fastapi import FastAPI
from starlette.middleware.cors import CORSMiddleware

from app.router import router, router_login
from app.cron import scheduler
import app.sql_app.database as sql_database

app = FastAPI()

# Define a list of allowed origins for CORS
origins = [
    "http://localhost:3000",
]

# Add the CORS middleware to the FastAPI app
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(router)
app.include_router(router_login)


async def startup_event():
    # Connect to the database and make sure the tables are created
    async with sql_database.engine.begin() as conn:
        await conn.run_sync(sql_database.Base.metadata.create_all)

    # Start the scheduler
    scheduler.start()


async def shutdown_event():
    # Shutdown the scheduler
    scheduler.shutdown()
    # Close the database connection
    await sql_database.engine.dispose()


app.add_event_handler("startup", startup_event)
app.add_event_handler("shutdown", shutdown_event)
